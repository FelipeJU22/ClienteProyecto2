package modelo;

public class Modelo {
	private Texto texto;

	public Modelo() {
		super();
		this.texto = new Texto();
	}
	public boolean busquedaBidireccional(){
		boolean res = false;
		return res;
	}
	public Texto getTexto() {
		return texto;
	}
}
